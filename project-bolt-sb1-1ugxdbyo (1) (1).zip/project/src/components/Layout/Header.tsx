import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Leaf, User, LogOut } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import AuthModal from '../Auth/AuthModal';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const location = useLocation();
  const { user, logout } = useAuth();

  const navItems = [
    { path: '/', label: 'Home' },
    ...(user?.role === 'farmer' ? [{ path: '/farmer', label: 'Farmer Dashboard' }] : []),
    ...(user?.role === 'consumer' ? [{ path: '/consumer', label: 'Shop' }] : []),
    ...(!user ? [
      { path: '/farmer', label: 'For Farmers' },
      { path: '/consumer', label: 'Shop' }
    ] : []),
    { path: '/contact', label: 'Contact' },
  ];

  const isActiveRoute = (path: string) => {
    return location.pathname === path;
  };

  const handleAuthClick = (mode: 'login' | 'register') => {
    setAuthMode(mode);
    setIsAuthModalOpen(true);
  };

  const handleLogout = () => {
    logout();
    setIsMenuOpen(false);
  };

  return (
    <>
      <header className="bg-emerald-600 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center space-x-2">
              <Leaf className="h-8 w-8 text-yellow-400" />
              <span className="text-white text-xl font-bold">Farm2Door</span>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              <nav className="flex space-x-8">
                {navItems.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${
                      isActiveRoute(item.path)
                        ? 'bg-emerald-700 text-yellow-400'
                        : 'text-white hover:bg-emerald-700 hover:text-yellow-400'
                    }`}
                  >
                    {item.label}
                  </Link>
                ))}
              </nav>
              
              {/* Auth Buttons */}
              {user ? (
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2 text-white">
                    <User className="h-4 w-4" />
                    <span className="text-sm">{user.name}</span>
                    <span className="text-xs bg-emerald-700 px-2 py-1 rounded-full">
                      {user.role}
                    </span>
                  </div>
                  <button
                    onClick={handleLogout}
                    className="text-white hover:text-yellow-400 transition-colors duration-200 flex items-center space-x-1"
                  >
                    <LogOut className="h-4 w-4" />
                    <span className="text-sm">Logout</span>
                  </button>
                </div>
              ) : (
                <div className="flex items-center space-x-4">
                  <button
                    onClick={() => handleAuthClick('login')}
                    className="text-white hover:text-yellow-400 transition-colors duration-200"
                  >
                    Sign In
                  </button>
                  <button
                    onClick={() => handleAuthClick('register')}
                    className="bg-yellow-400 text-emerald-900 px-4 py-2 rounded-md font-semibold hover:bg-yellow-300 transition-colors duration-200"
                  >
                    Sign Up
                  </button>
                </div>
              )}
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-white hover:text-yellow-400 transition-colors duration-200"
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden">
              <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-emerald-700">
                {navItems.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setIsMenuOpen(false)}
                    className={`block px-3 py-2 rounded-md text-base font-medium transition-colors duration-200 ${
                      isActiveRoute(item.path)
                        ? 'bg-emerald-800 text-yellow-400'
                        : 'text-white hover:bg-emerald-800 hover:text-yellow-400'
                    }`}
                  >
                    {item.label}
                  </Link>
                ))}
                
                {/* Mobile Auth Buttons */}
                <div className="border-t border-emerald-600 pt-3 mt-3">
                  {user ? (
                    <div className="space-y-2">
                      <div className="px-3 py-2 text-white">
                        <div className="flex items-center space-x-2">
                          <User className="h-4 w-4" />
                          <span>{user.name}</span>
                          <span className="text-xs bg-emerald-600 px-2 py-1 rounded-full">
                            {user.role}
                          </span>
                        </div>
                      </div>
                      <button
                        onClick={handleLogout}
                        className="w-full text-left px-3 py-2 text-white hover:bg-emerald-800 hover:text-yellow-400 transition-colors duration-200 flex items-center space-x-2"
                      >
                        <LogOut className="h-4 w-4" />
                        <span>Logout</span>
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <button
                        onClick={() => {
                          handleAuthClick('login');
                          setIsMenuOpen(false);
                        }}
                        className="w-full text-left px-3 py-2 text-white hover:bg-emerald-800 hover:text-yellow-400 transition-colors duration-200"
                      >
                        Sign In
                      </button>
                      <button
                        onClick={() => {
                          handleAuthClick('register');
                          setIsMenuOpen(false);
                        }}
                        className="w-full text-left px-3 py-2 bg-yellow-400 text-emerald-900 font-semibold hover:bg-yellow-300 transition-colors duration-200 rounded-md mx-3"
                      >
                        Sign Up
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </header>
      
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        initialMode={authMode}
      />
    </>
  );
};

export default Header;