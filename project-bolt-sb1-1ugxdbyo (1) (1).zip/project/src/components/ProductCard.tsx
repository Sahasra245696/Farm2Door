import React from 'react';
import { ShoppingCart, MapPin } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onBuyNow?: (product: Product) => void;
  showBuyButton?: boolean;
}

const ProductCard: React.FC<ProductCardProps> = ({ 
  product, 
  onBuyNow, 
  showBuyButton = true 
}) => {
  const handleBuyNow = () => {
    if (onBuyNow) {
      onBuyNow(product);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <div className="h-48 overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
        />
      </div>
      
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-semibold text-gray-900">{product.name}</h3>
          <span className="text-xl font-bold text-emerald-600">₹{product.price}</span>
        </div>
        
        <div className="flex items-center text-gray-600 mb-2">
          <MapPin className="h-4 w-4 mr-1" />
          <span className="text-sm">{product.farmerName}</span>
        </div>
        
        <p className="text-gray-600 text-sm mb-3 line-clamp-2">
          {product.description}
        </p>
        
        <div className="flex justify-between items-center mb-3">
          <span className="text-sm text-gray-500">
            Available: {product.quantity} units
          </span>
          <span className="text-xs bg-emerald-100 text-emerald-800 px-2 py-1 rounded-full">
            {product.category}
          </span>
        </div>
        
        {showBuyButton && (
          <button
            onClick={handleBuyNow}
            className="w-full bg-emerald-600 text-white py-2 px-4 rounded-md hover:bg-emerald-700 transition-colors duration-200 flex items-center justify-center space-x-2"
          >
            <ShoppingCart className="h-4 w-4" />
            <span>Buy Now</span>
          </button>
        )}
      </div>
    </div>
  );
};

export default ProductCard;