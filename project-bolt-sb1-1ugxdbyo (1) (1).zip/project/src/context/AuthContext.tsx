import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { User, LoginForm, RegisterForm } from '../types';

interface AuthContextType {
  user: User | null;
  login: (credentials: LoginForm) => Promise<boolean>;
  register: (userData: RegisterForm) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Dummy users for demonstration
const dummyUsers: (User & { password: string })[] = [
  {
    id: '1',
    email: 'farmer@farm2door.com',
    password: 'farmer123',
    name: 'John Farmer',
    role: 'farmer',
    location: 'Green Valley, CA'
  },
  {
    id: '2',
    email: 'consumer@farm2door.com',
    password: 'consumer123',
    name: 'Jane Consumer',
    role: 'consumer',
    location: 'City Center, CA'
  },
  {
    id: '3',
    email: 'admin@farm2door.com',
    password: 'admin123',
    name: 'Admin User',
    role: 'farmer',
    location: 'Hyderabad, Telangana'
  }
];

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for stored user session
    const storedUser = localStorage.getItem('farm2door_user');
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (error) {
        localStorage.removeItem('farm2door_user');
      }
    }
    setIsLoading(false);
  }, []);

  const login = async (credentials: LoginForm): Promise<boolean> => {
    setIsLoading(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const foundUser = dummyUsers.find(
      u => u.email === credentials.email && u.password === credentials.password
    );
    
    if (foundUser) {
      const { password, ...userWithoutPassword } = foundUser;
      setUser(userWithoutPassword);
      localStorage.setItem('farm2door_user', JSON.stringify(userWithoutPassword));
      setIsLoading(false);
      return true;
    }
    
    setIsLoading(false);
    return false;
  };

  const register = async (userData: RegisterForm): Promise<boolean> => {
    setIsLoading(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Check if user already exists
    const existingUser = dummyUsers.find(u => u.email === userData.email);
    if (existingUser) {
      setIsLoading(false);
      return false;
    }
    
    // Create new user
    const newUser: User = {
      id: Date.now().toString(),
      email: userData.email,
      name: userData.name,
      role: userData.role,
      location: userData.location
    };
    
    // Add to dummy users (in real app, this would be an API call)
    dummyUsers.push({ ...newUser, password: userData.password });
    
    setUser(newUser);
    localStorage.setItem('farm2door_user', JSON.stringify(newUser));
    setIsLoading(false);
    return true;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('farm2door_user');
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};