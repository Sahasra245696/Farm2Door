import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Product } from '../types';

interface ProductContextType {
  products: Product[];
  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
}

const ProductContext = createContext<ProductContextType | undefined>(undefined);

export const useProducts = () => {
  const context = useContext(ProductContext);
  if (!context) {
    throw new Error('useProducts must be used within a ProductProvider');
  }
  return context;
};

// Dummy data for demonstration
const initialProducts: Product[] = [
  {
    id: '1',
    name: 'Organic Tomatoes',
    quantity: 50,
    price: 80,
    image: 'https://images.pexels.com/photos/533280/pexels-photo-533280.jpeg?auto=compress&cs=tinysrgb&w=800',
    farmerId: 'farmer1',
    farmerName: 'Green Valley Farm',
    description: 'Fresh, organic tomatoes grown without pesticides',
    category: 'Vegetables'
  },
  {
    id: '2',
    name: 'Fresh Strawberries',
    quantity: 30,
    price: 120,
    image: 'https://images.pexels.com/photos/89778/strawberries-frisch-ripe-sweet-89778.jpeg?auto=compress&cs=tinysrgb&w=800',
    farmerId: 'farmer2',
    farmerName: 'Berry Bliss Farm',
    description: 'Sweet, juicy strawberries picked fresh daily',
    category: 'Fruits'
  },
  {
    id: '3',
    name: 'Organic Carrots',
    quantity: 40,
    price: 60,
    image: 'https://images.pexels.com/photos/143133/pexels-photo-143133.jpeg?auto=compress&cs=tinysrgb&w=800',
    farmerId: 'farmer1',
    farmerName: 'Green Valley Farm',
    description: 'Crunchy organic carrots, perfect for snacking',
    category: 'Vegetables'
  },
  {
    id: '4',
    name: 'Farm Fresh Eggs',
    quantity: 100,
    price: 8,
    image: 'https://images.pexels.com/photos/162712/egg-white-food-protein-162712.jpeg?auto=compress&cs=tinysrgb&w=800',
    farmerId: 'farmer3',
    farmerName: 'Sunny Side Farm',
    description: 'Free-range eggs from happy hens',
    category: 'Dairy & Eggs'
  },
  {
    id: '5',
    name: 'Organic Spinach',
    quantity: 25,
    price: 40,
    image: 'https://images.pexels.com/photos/2325843/pexels-photo-2325843.jpeg?auto=compress&cs=tinysrgb&w=800',
    farmerId: 'farmer2',
    farmerName: 'Berry Bliss Farm',
    description: 'Nutrient-rich organic spinach leaves',
    category: 'Vegetables'
  },
  {
    id: '6',
    name: 'Fresh Apples',
    quantity: 60,
    price: 90,
    image: 'https://images.pexels.com/photos/102104/pexels-photo-102104.jpeg?auto=compress&cs=tinysrgb&w=800',
    farmerId: 'farmer3',
    farmerName: 'Sunny Side Farm',
    description: 'Crisp, sweet apples perfect for any occasion',
    category: 'Fruits'
  }
];

export const ProductProvider = ({ children }: { children: ReactNode }) => {
  const [products, setProducts] = useState<Product[]>(initialProducts);

  const addProduct = (product: Omit<Product, 'id'>) => {
    const newProduct: Product = {
      ...product,
      id: Date.now().toString(),
      farmerId: product.farmerId || 'current-farmer',
      farmerName: product.farmerName || 'Your Farm'
    };
    setProducts(prev => [...prev, newProduct]);
  };

  const updateProduct = (id: string, updatedProduct: Partial<Product>) => {
    setProducts(prev =>
      prev.map(product =>
        product.id === id ? { ...product, ...updatedProduct } : product
      )
    );
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(product => product.id !== id));
  };

  return (
    <ProductContext.Provider value={{ products, addProduct, updateProduct, deleteProduct }}>
      {children}
    </ProductContext.Provider>
  );
};