import React, { useState } from 'react';
import { Search, Filter, ShoppingCart, Lock } from 'lucide-react';
import { useProducts } from '../context/ProductContext';
import { useAuth } from '../context/AuthContext';
import ProductCard from '../components/ProductCard';
import { Product } from '../types';
import AuthModal from '../components/Auth/AuthModal';

const ConsumerDashboard = () => {
  const { products } = useProducts();
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [sortBy, setSortBy] = useState('name');
  const [showAuthModal, setShowAuthModal] = useState(false);

  const categories = ['All', ...Array.from(new Set(products.map(product => product.category)))];

  const filteredProducts = products
    .filter(product => {
      const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           product.description?.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'price-low':
          return a.price - b.price;
        case 'price-high':
          return b.price - a.price;
        case 'name':
          return a.name.localeCompare(b.name);
        default:
          return 0;
      }
    });

  const handleBuyNow = (product: Product) => {
    if (!user) {
      setShowAuthModal(true);
      return;
    }
    alert(`Great choice, ${user.name}! You've selected ${product.name} for ₹${product.price}. In a real app, this would proceed to checkout.`);
  };

  return (
    <>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Fresh Produce Marketplace</h1>
            <p className="text-gray-600 mt-2">
              {user ? `Welcome ${user.name}! ` : ''}Discover fresh, local produce from farmers in your area
            </p>
            {!user && (
              <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <p className="text-yellow-800 text-sm">
                  <Lock className="h-4 w-4 inline mr-1" />
                  Sign in to purchase products and track your orders.{' '}
                  <button
                    onClick={() => setShowAuthModal(true)}
                    className="font-medium text-yellow-900 hover:text-yellow-700 underline"
                  >
                    Sign in now
                  </button>
                </p>
              </div>
            )}
          </div>

          {/* Filters and Search */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <div className="flex flex-col lg:flex-row lg:items-center lg:space-x-6 space-y-4 lg:space-y-0">
              {/* Search */}
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <input
                    type="text"
                    placeholder="Search for products..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {/* Category Filter */}
              <div className="flex items-center space-x-2">
                <Filter className="h-5 w-5 text-gray-400" />
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  {categories.map(category => (
                    <option key={category} value={category}>{category}</option>
                  ))}
                </select>
              </div>

              {/* Sort */}
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-600">Sort by:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="name">Name</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                </select>
              </div>
            </div>
          </div>

          {/* Results Header */}
          <div className="flex justify-between items-center mb-6">
            <p className="text-gray-600">
              Showing {filteredProducts.length} of {products.length} products
            </p>
            {filteredProducts.length > 0 && (
              <button className="bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition-colors flex items-center space-x-2">
                <ShoppingCart className="h-4 w-4" />
                <span>View Cart (0)</span>
              </button>
            )}
          </div>

          {/* Products Grid */}
          {filteredProducts.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-gray-400 mb-4">
                <Search className="h-12 w-12 mx-auto" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No products found</h3>
              <p className="text-gray-600">Try adjusting your search or filters</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onBuyNow={handleBuyNow}
                  showBuyButton={user?.role !== 'farmer'}
                />
              ))}
            </div>
          )}

          {/* Featured Farmers Section */}
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Featured Farmers</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                {
                  name: 'Green Valley Farm',
                  location: 'Organic Valley, CA',
                  image: 'https://images.pexels.com/photos/2252618/pexels-photo-2252618.jpeg?auto=compress&cs=tinysrgb&w=400',
                  products: products.filter(p => p.farmerName === 'Green Valley Farm').length
                },
                {
                  name: 'Berry Bliss Farm',
                  location: 'Fruitland, OR',
                  image: 'https://images.pexels.com/photos/1458682/pexels-photo-1458682.jpeg?auto=compress&cs=tinysrgb&w=400',
                  products: products.filter(p => p.farmerName === 'Berry Bliss Farm').length
                },
                {
                  name: 'Sunny Side Farm',
                  location: 'Fresh Fields, WA',
                  image: 'https://images.pexels.com/photos/1268101/pexels-photo-1268101.jpeg?auto=compress&cs=tinysrgb&w=400',
                  products: products.filter(p => p.farmerName === 'Sunny Side Farm').length
                }
              ].map((farmer, index) => (
                <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
                  <img
                    src={farmer.image}
                    alt={farmer.name}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-4">
                    <h3 className="text-lg font-semibold text-gray-900">{farmer.name}</h3>
                    <p className="text-gray-600">{farmer.location}</p>
                    <p className="text-sm text-emerald-600 mt-2">{farmer.products} products available</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        initialMode="login"
      />
    </>
  );
};

export default ConsumerDashboard;