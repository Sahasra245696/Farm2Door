import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Leaf, Users, Truck, Heart } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const Home = () => {
  const { user } = useAuth();
  
  const features = [
    {
      icon: <Leaf className="h-8 w-8 text-emerald-600" />,
      title: 'Fresh & Organic',
      description: 'Direct from local farms to your table, ensuring maximum freshness and quality.'
    },
    {
      icon: <Users className="h-8 w-8 text-emerald-600" />,
      title: 'Support Local Farmers',
      description: 'Help sustainable agriculture thrive by connecting directly with local producers.'
    },
    {
      icon: <Truck className="h-8 w-8 text-emerald-600" />,
      title: 'Farm-to-Door Delivery',
      description: 'Skip the middleman and get fresh produce delivered straight to your doorstep.'
    },
    {
      icon: <Heart className="h-8 w-8 text-emerald-600" />,
      title: 'Community Focused',
      description: 'Building stronger communities through sustainable agriculture and local commerce.'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-emerald-600 to-emerald-800 text-white">
        <div className="absolute inset-0 bg-black opacity-20"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl lg:text-6xl font-bold mb-6 leading-tight">
                Connecting
                <span className="text-yellow-400"> Farmers </span>
                to
                <span className="text-yellow-400"> Consumers</span>
              </h1>
              <p className="text-xl lg:text-2xl mb-8 text-emerald-100">
                Fresh, local produce delivered directly from farm to your door. 
                Support sustainable agriculture while enjoying the finest quality food.
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                <Link
                  to="/consumer"
                  className="bg-yellow-400 text-emerald-900 px-8 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors duration-200 flex items-center justify-center space-x-2"
                >
                  <span>Start Shopping</span>
                  <ArrowRight className="h-5 w-5" />
                </Link>
                <Link
                  to={user?.role === 'farmer' ? '/farmer' : '/farmer'}
                  className="bg-transparent border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-emerald-900 transition-colors duration-200 flex items-center justify-center"
                >
                  {user?.role === 'farmer' ? 'Go to Dashboard' : "I'm a Farmer"}
                </Link>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/2518861/pexels-photo-2518861.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Fresh vegetables and fruits"
                className="rounded-lg shadow-2xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-yellow-400 text-emerald-900 p-4 rounded-lg font-semibold shadow-lg">
                <p className="text-sm">🌱 100% Organic</p>
                <p className="text-sm">🚚 Farm Fresh Daily</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Our Mission
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We're revolutionizing the agricultural supply chain by creating direct connections 
              between farmers and consumers, promoting sustainable farming practices, and ensuring 
              everyone has access to fresh, healthy produce.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              How Farm2Door Works
            </h2>
            <p className="text-xl text-gray-600">
              Simple steps to connect farmers with consumers
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-emerald-600">1</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Farmers List Products</h3>
              <p className="text-gray-600">
                Local farmers create listings for their fresh produce with photos, descriptions, and pricing.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-emerald-600">2</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Consumers Browse & Buy</h3>
              <p className="text-gray-600">
                Customers discover fresh, local produce and place orders directly with farmers.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-emerald-600">3</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Fresh Delivery</h3>
              <p className="text-gray-600">
                Products are delivered fresh from the farm directly to the customer's door.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-emerald-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-xl mb-8 text-emerald-100">
            Join thousands of farmers and consumers who are already part of our sustainable agriculture community.
          </p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <Link
              to="/farmer"
              className="bg-yellow-400 text-emerald-900 px-8 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors duration-200"
            >
              {user?.role === 'farmer' ? 'Go to Dashboard' : 'Join as a Farmer'}
            </Link>
            <Link
              to="/consumer"
              className="bg-transparent border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-emerald-900 transition-colors duration-200"
            >
              {user?.role === 'consumer' ? 'Go to Shop' : 'Start Shopping'}
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;