export interface Product {
  id: string;
  name: string;
  quantity: number;
  price: number;
  image: string;
  farmerId: string;
  farmerName: string;
  description?: string;
  category: string;
}

export interface Farmer {
  id: string;
  name: string;
  email: string;
  location: string;
}

export interface ContactForm {
  name: string;
  email: string;
  subject: string;
  message: string;
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'farmer' | 'consumer';
  location?: string;
}

export interface LoginForm {
  email: string;
  password: string;
}

export interface RegisterForm {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
  role: 'farmer' | 'consumer';
  location?: string;
}